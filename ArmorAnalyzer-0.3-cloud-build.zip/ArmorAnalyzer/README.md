# Armor Analyzer 0.1 — Android prototype

This Android Studio project is a first technical prototype for the GunBound World research workflow. It asks Android for explicit screen-capture permission, runs on-device ML Kit OCR on periodic frames, displays recognized text and exports timestamped OCR results to CSV.

## Current capabilities
- User-authorized screen capture via Android MediaProjection.
- On-device OCR (Latin text recognition).
- Timestamped text log and CSV export in the app-specific external files directory.
- No game input automation, no overlay, and no automated aiming.

## Important limitations
- This is source code, not a compiled APK. It has not been built or device-tested in this environment.
- OCR currently reads the whole frame and does not yet classify fields such as angle, power, wind, vehicle, or impact. Recognized text must be manually checked.
- This prototype targets SDK 32 for compatibility with the initial Android 12 test device. Before wider distribution, update the capture architecture for current Android foreground-service / MediaProjection requirements and test on the target OS versions.
- Android may stop capture when the user leaves the app depending on device/version. Approve the system capture prompt and follow the device's capture indicator.

## Build
1. Install Android Studio with Android SDK 35 and a compatible JDK (17 recommended).
2. Open this folder as an existing Android Studio project.
3. Let Gradle sync and download dependencies.
4. Connect an Android device with USB debugging enabled or use an emulator, then run `app`.
5. To make an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Next steps
1. Validate compilation and screen capture on the actual Android phone.
2. Restrict OCR to the UI regions containing angle, power and wind.
3. Parse recognized values with confidence checks and a manual correction screen.
4. Add a structured shot log (vehicle, shot type, angle, power, wind, terrain and observed impact).
5. Calibrate any trajectory model only with measured shots and known game conditions.
