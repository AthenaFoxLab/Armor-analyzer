# Build Armor Analyzer APK from an Android phone (cloud build)

This project can be compiled on GitHub Actions without installing Android Studio on your phone. The cloud build is not automatic until you upload the project to a GitHub repository.

## Phone-only workflow
1. Download and extract this ZIP with your Android file manager (or an archive app).
2. In your browser, sign in to GitHub and create a repository. A private repository is fine; GitHub Actions has included free usage for standard runners within account limits. Keep this source private if you prefer.
3. Upload the *contents* of the `ArmorAnalyzer` project folder to the repository root, including the hidden `.github/workflows/android-apk.yml` file. If your phone's file picker hides dot-folders or cannot upload a folder tree, use GitHub's web upload UI in desktop-site mode or a Git client that supports folder uploads.
4. Open the repository's **Actions** tab, select **Build Armor Analyzer APK**, and tap **Run workflow**. The workflow also starts after a push to `main`.
5. Wait for the run to finish. If successful, open that run and scroll to **Artifacts**; download `ArmorAnalyzer-debug-apk` and extract it to obtain the `.apk`.
6. Tap the APK to install. Android may ask you to allow your browser/file manager to install unknown apps. Only allow this for the app you used to download the artifact, and turn the permission off again afterwards if desired.

## Notes
- This produces a debug/test APK, not a Play Store release.
- A successful cloud build does not prove screen capture/OCR works correctly on every phone; test it on the POCO X3 Pro.
- Do not put passwords, signing keys, or personal data into the repository.
