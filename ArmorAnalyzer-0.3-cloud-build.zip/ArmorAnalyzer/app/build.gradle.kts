plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.athena.armoranalyzer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.athena.armoranalyzer"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1-test"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
