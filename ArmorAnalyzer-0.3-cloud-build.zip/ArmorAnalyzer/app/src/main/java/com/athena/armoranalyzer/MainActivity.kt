package com.athena.armoranalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Prototype: user-approved screen capture + OCR. It records recognized screen text only;
 * it does not control the game or provide automated aiming.
 */
class MainActivity : Activity() {
    private val requestCapture = 501
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var exportButton: Button
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val busy = AtomicBoolean(false)
    private val lines = mutableListOf<String>()
    private var lastProcessedAt = 0L
    private var captureWidth = 0
    private var captureHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
        }
        val title = TextView(this).apply {
            text = "Armor Analyzer · 0.1"
            textSize = 24f
        }
        status = TextView(this).apply {
            text = "Estado: listo. Abre GunBound y pulsa Iniciar captura."
            textSize = 15f
            setPadding(0, 16, 0, 16)
        }
        startButton = Button(this).apply {
            text = "Iniciar captura de pantalla"
            setOnClickListener { requestScreenCapture() }
        }
        stopButton = Button(this).apply {
            text = "Detener captura"
            isEnabled = false
            setOnClickListener { stopCapture() }
        }
        exportButton = Button(this).apply {
            text = "Exportar registro CSV"
            setOnClickListener { exportCsv() }
        }
        val note = TextView(this).apply {
            text = "La captura requiere tu autorización de Android. El OCR es experimental: verifica los valores antes de usarlos. Las imágenes se procesan localmente y no se guardan."
            textSize = 13f
            setPadding(0, 8, 0, 12)
        }
        output = TextView(this).apply {
            text = "Lecturas reconocidas aparecerán aquí."
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title)
        root.addView(status)
        root.addView(startButton, matchWidth())
        root.addView(stopButton, matchWidth())
        root.addView(exportButton, matchWidth())
        root.addView(note)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCapture) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Captura cancelada. No se grabó nada."
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            beginCapture()
        } catch (e: Exception) {
            status.text = "No se pudo iniciar la captura: ${e.message}"
        }
    }

    private fun beginCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        captureWidth = metrics.widthPixels
        captureHeight = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastProcessedAt < 1200 || !busy.compareAndSet(false, true)) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = source.acquireLatestImage()
            if (image == null) {
                busy.set(false)
                return@setOnImageAvailableListener
            }
            lastProcessedAt = now
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * captureWidth
                val paddedBitmap = Bitmap.createBitmap(
                    captureWidth + rowPadding / pixelStride,
                    captureHeight,
                    Bitmap.Config.ARGB_8888
                )
                paddedBitmap.copyPixelsFromBuffer(buffer)
                val bitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, captureWidth, captureHeight)
                paddedBitmap.recycle()
                image.close()
                runOcr(bitmap)
            } catch (e: Exception) {
                try { image.close() } catch (_: Exception) {}
                busy.set(false)
            }
        }, mainHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "ArmorAnalyzerCapture", captureWidth, captureHeight, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, mainHandler
        )
        startButton.isEnabled = false
        stopButton.isEnabled = true
        status.text = "Capturando. Cambia a GunBound; vuelve aquí para detener y exportar."
        Toast.makeText(this, "Captura activa mientras Android mantenga el permiso", Toast.LENGTH_LONG).show()
    }

    private fun runOcr(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text.trim()
                if (text.isNotBlank()) {
                    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                    val record = "$stamp,\"${text.replace("\"", "\"\"").replace("\n", " | ")}\""
                    synchronized(lines) { lines.add(record) }
                    mainHandler.post {
                        output.text = (synchronized(lines) { lines.takeLast(30).joinToString("\n\n") })
                    }
                }
            }
            .addOnFailureListener { err ->
                mainHandler.post { status.text = "OCR: ${err.localizedMessage ?: "error de lectura"}" }
            }
            .addOnCompleteListener {
                bitmap.recycle()
                busy.set(false)
            }
    }

    private fun stopCapture() {
        virtualDisplay?.release(); virtualDisplay = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close(); reader = null
        projection?.stop(); projection = null
        startButton.isEnabled = true
        stopButton.isEnabled = false
        status.text = "Captura detenida. ${synchronized(lines) { lines.size }} lecturas OCR guardadas en memoria."
    }

    private fun exportCsv() {
        val snapshot = synchronized(lines) { lines.toList() }
        if (snapshot.isEmpty()) {
            Toast.makeText(this, "Todavía no hay lecturas para exportar", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = File(getExternalFilesDir(null), "armor_ocr_${System.currentTimeMillis()}.csv")
            FileOutputStream(file).use { stream ->
                stream.write("timestamp,recognized_text\n".toByteArray(Charsets.UTF_8))
                snapshot.forEach { stream.write((it + "\n").toByteArray(Charsets.UTF_8)) }
            }
            status.text = "CSV guardado en: ${file.absolutePath}"
            Toast.makeText(this, "CSV guardado en almacenamiento de la app", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "Error al exportar: ${e.message}"
        }
    }

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
